                        Table � public.etudiants �
  Colonne   |       Type        | Collationnement | NULL-able | Par d�faut 
------------+-------------------+-----------------+-----------+------------
 numetu     | integer           |                 | not null  | 
 nometu     | character varying |                 |           | 
 prenometu  | character varying |                 |           | 
 adretu     | character varying |                 |           | 
 viletu     | character varying |                 |           | 
 cpetu      | integer           |                 |           | 
 teletu     | character varying |                 |           | 
 datentetu  | date              |                 |           | 
 annetu     | integer           |                 |           | 
 remetu     | character varying |                 |           | 
 sexetu     | character varying |                 |           | 
 datenaietu | date              |                 |           | 
Index :
    "etudiants_pkey" PRIMARY KEY, btree (numetu)
R�f�renc� par :
    TABLE "avoir_note" CONSTRAINT "fk_avoir_note_numetu" FOREIGN KEY (numetu) REFERENCES etudiants(numetu)

 numetu |   nometu    
--------+-------------
      1 | roblin
      2 | athur
      3 | minol
      4 | bagnole
      5 | bury
      6 | vendraux
      7 | vendermaele
      8 | besson
      9 | jean-paul
(9 lignes)

