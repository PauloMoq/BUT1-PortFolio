-- Creation des tables de la database police
-- Monsieur CAPITAINE
-- BUT 1 informatique
-- avril 2022

-- table proprietaire
 insert into proprietaire values (1, 'capitaine', 'dany', 'saint-omer');
 insert into proprietaire values (2, 'synave', 'remi', 'calais');

-- table voiture
insert into voiture values ( '75PM8962', 'ferrari', 'Ferrari Daytona SP3', 'rouge', 1);
insert into voiture values ( 'ZZAC8462', 'lada', 'lada2107', 'bleu', 2);

--table situation
insert into situation values (1, 'cimetiere');
insert into situation values (2, 'place d||'||'armes');

--table infraction
insert into infraction values (2548, 'classe1', 'clignotant absent', '35');

--table commettre 
insert into commettre values ('75PM8962',1,2548,'28-03-2022');
----------------------------------------
--Sailly Kévin
----------------------------------------
-- table proprietaire
 insert into proprietaire values (3, 'Xina', 'John', 'Beijing');
 insert into proprietaire values (4, 'Wok', 'The', 'Pekin');
 insert into proprietaire values (5, 'Musk', 'Xilon', 'Wuhan');

-- table voiture
insert into voiture values ( 'CD854LP', 'ferrari', 'Daytona SP3', 'rouge', 3);
insert into voiture values ( 'AA123BB', 'lada', 'lada2107', 'bleu', 4);
insert into voiture values ( 'VF458ZD', 'Tesxa', 'ModelS', 'Verte', 5);

--table situation
insert into situation values (3, 'Ecole');
insert into situation values (4, 'Mairie');

--table infraction
insert into infraction values (1249, 'classe3', 'Aucun contrôle technique', '35');


----------------------------------------

--Corion Gauthier
----------------------------------------
-- table proprietaire
insert into proprietaire values (6, 'Henri', 'Matisse', 'Nice');
insert into proprietaire values (7, 'Claude', 'Monet', 'Paris');
insert into proprietaire values (8, 'Eugène', 'Delacroix', 'Paris');

-- table voiture
insert into voiture values ( 'OR333DI', 'porsche', 'Boxster 987', 'rouge', 6);
insert into voiture values ( 'WI111FI', 'citroen', 'Cactus', 'blanche', 7);

--table situation
insert into situation values (5, 'Gare de Calais');
insert into situation values (6, 'Théatre');
insert into situation values (7, 'Piscine');

--table infraction
insert into infraction values (2233, 'classe2', 'Non-paiement d||'||'un péage ;', '75');

--table commettre 
insert into commettre values ('OR333DI', 6,2233,'02-03-2022');

-- Caron Samuel
----------------------------------------
-- table proprietaire
insert into proprietaire values(9, 'Jean', 'Pierre', 'Montcuq');
insert into proprietaire values(10, 'Drexler', 'Henrietta', 'Strasbourg');
insert into proprietaire values(11, 'Ivanov', 'Dmitri', 'Minsk');

-- table voiture
insert into voiture values('XVB4R4R', 'audi', 'rs3', 'noire', 9);
insert into voiture values('E8TYU45', 'suzuki', 'x90', 'rouge' 10);
insert into voiture values('RYD98MP', 'gaz', 'volga', 'rose', 11);

--table situation
insert into situation values(8, 'Parc');
insert into situation values(9, 'Patinoire');
insert into situation values(10, 'Bar');

-- table infraction
insert into infraction values(1782 ,'classe4', 'Alcool au volant', '375');



----------------------------------------
--Lovergne Alex
----------------------------------------
-- table proprietaire
insert into proprietaire values (12, 'Simp', 'Noe', 'Marseille');
insert into proprietaire values (13, 'Bauzo', 'Oratio', 'Boulogne');
insert into proprietaire values (14, 'Higa', 'Oren', 'Calais');

-- table voiture
insert into voiture values ( 'CV555OG', 'renault', 'Clio', 'blanche', 12);
insert into voiture values ( 'PD123MD', 'fiat', 'Multipla', 'rouge', 14);

--table situation
insert into situation values (12, 'IUTLCO');
insert into situation values (13, 'Le Channel');
insert into situation values (14, 'McDonalds');

--table infraction
insert into infraction values (4569, 'classe3', 'Pas d||'||'essuie glasse;', '70');

--table commettre 
insert into commettre values ('PD123MD',14,4569,'22-03-2022');

----------------------------------------
--ELUECQUE Anthony
----------------------------------------
-- table proprietaire
insert into proprietaire values (15, 'Terre', 'Jean', 'Calais');
insert into proprietaire values (16, 'Fautré', 'Thibault', 'Lille');
insert into proprietaire values (17, 'Seidman', 'Thomas', 'Marseille');

-- table voiture
insert into voiture values ( 'E750PZZ', 'citroen', 'c4 picasso', 'noir', 15);
insert into voiture values ( 'R4T1OLL', 'citroen', 'c3 picasso', 'noir', 17);

--table situation
insert into situation values (15, 'Mairie de Calais');
insert into situation values (16, 'Théatre');
insert into situation values (17, 'Patinoire');

--table infraction
insert into infraction values (3590, 'classe4', 'Pas de frein ;', '125');



----------------------------------------
--LECLERCQ Tom
----------------------------------------


-- table voiture
insert into voiture values ( 'ZSP5CLQ4', 'Toyota', 'Supra MK4', 'noir', 4);
insert into voiture values ( 'D65ZFDPF', 'Ford', 'Mustang Shelby GT500', 'gris', 3);
insert into voiture values ( 'CLC1SD53', 'Citroen', 'Xantia EXCLUSIVE', 'bleu', 3);
insert into voiture values ( '5D4S5CDS', 'BMW', 'M3 F80', 'jaune', 1);
insert into voiture values ( 'JHEZJ65X', 'Porsche', '911 GT2RS', 'gris', 4);
insert into voiture values ( 'LSQF845S', 'BMW', 'serie 3 e36', 'marron', 1);

--table infraction
insert into infraction values (416,  'classe3', 'fumée noire', '450');
insert into infraction values (3251, 'classe4', 'echappement trop bruyant', '135');
insert into infraction values (5612, 'classe4', 'pare brise teinté', '135');

--table commettre 
insert into commettre values ('LSQF845S', 1,416,'21-08-2020');
insert into commettre values ('D65ZFDPF', 3,3251,'16-01-2018');
insert into commettre values ('D65ZFDPF', 3,5612,'16-01-2018');
insert into commettre values ('ZSP5CLQ4', 4,3251,'14-11-2021');
insert into commettre values ('CLC1SD53', 3,416,'13-11-2021');


----------------------------------------
--BRENEL Pierre
----------------------------------------

--table infraction
insert into infraction values (46431,  'classe4', 'Dépassement dangereux', '135');
insert into infraction values (3851, 'classe4', 'Conduite en état alcoolique', '135');
insert into infraction values (7895, 'classe5', 'Excès de vitesse supérieur à 50 km/h.', '750');
insert into infraction values (5681, 'classe4', 'Circulation en sens interdit', '175');
insert into infraction values (9524, 'classe4', 'Refus de priorité', '105');

--table commettre 
insert into commettre values ('LSQF845S', 2,9524,'24-04-2020');
insert into commettre values ('D65ZFDPF', 2,5681,'16-06-2013');
insert into commettre values ('D65ZFDPF', 3,7895,'10-11-2015');
insert into commettre values ('ZSP5CLQ4', 6,3851,'09-04-2016');
insert into commettre values ('CLC1SD53', 6,46431,'22-02-2022');



----------------------------------------
--DOURNEL FREDERIC
----------------------------------------

--table infraction
insert into infraction values (453,  'classe4', 'Excès de lenteur', '135');
insert into infraction values (757, 'classe4', 'Conduite en état alcoolique', '135');
insert into infraction values (942, 'classe5', 'Délit de fuite', '75000');
insert into infraction values (662, 'classe4', 'Garé sur passage pieton', '135');
insert into infraction values (988, 'classe4', 'passager majeur pas attaché', '135');

----------------------------------------
--          Vandaele Joshua           --
----------------------------------------

-- Table infraction
INSERT INTO infraction VALUES (500, 'classe1', 'Stationnement interdit', '38');
INSERT INTO infraction VALUES (501, 'classe2', 'Téléphone au volant', '135');
INSERT INTO infraction VALUES (502, 'classe3', 'Circulation en l’absence de dispositifs de freinage conformes', '400');
INSERT INTO infraction VALUES (503, 'classe4', 'Conduite en état d’ivresse', '750');
INSERT INTO infraction VALUES (504, 'classe5', 'Excès de vitesse supérieur à 50 km/h', '1500');

-- Table commettre 
INSERT INTO commettre VALUES ('AA123BB', 1, 500, '28-01-2003');
INSERT INTO commettre VALUES ('D65ZFDPF', 2, 501, '05-03-2004');
INSERT INTO commettre VALUES ('JHEZJ65X', 4, 503, '02-05-2006');
INSERT INTO commettre VALUES ('LSQF845S', 5, 504, '26-11-2015');

----------------------------------------
-- OGES FLORIAN
----------------------------------------
--table infraction
insert into infraction values (3034, 'classe4', 'Usage du téléphone tenu en main', '135');
insert into infraction values (6666, 'classe4', 'Circulation sur la bande d||'||'arrêt d||'||'urgence', '135');
insert into infraction values (2507, 'classe4', 'Conduite sans ceinture de sécurité', '135');
insert into infraction values (9647, 'classe4', 'Refus de priorité', '135');
insert into infraction values (58, 'classe4', 'Non respect d||'||'un feu rouge', '135');
insert into infraction values (4956, 'classe4', 'Non respect d||'||'un stop', '135');
insert into infraction values (2047, 'classe4', 'Franchissement d||'||'une ligne continue', '135');
insert into infraction values (9999, 'classe4', 'Circulation sans éclairage', '135');
insert into infraction values (9785, 'classe4', 'Dépassement dangereux', '135');
insert into infraction values (6549, 'classe4', 'Absence de certificat d||'||'immatriculation', '135');
insert into infraction values (9829, 'classe4', 'Non respect de la distance de sécurité', '135');

----------------------------------------
-----------------------------------------
-------------- YOURI STECKO -------------
-----------------------------------------

--table proprietaire
insert into proprietaire values (31, 'stecko', 'youri', 'lille');
insert into proprietaire values (42, 'morgana', 'yuri', 'Pékin');
insert into proprietaire values (51, 'garen', 'steven', 'paris');
insert into proprietaire values (32, 'yii', 'matheo', 'Beijing');
insert into proprietaire values (41, 'vargas', 'pablo', 'mexico');
insert into proprietaire values (52, 'musk', 'elon', 'californie');

--table voiture
insert into voiture values ( 'CLGHKOPP', 'Ford', 'Mustang', 'noir', 3);
insert into voiture values ( '5D4S587S', 'BMW', 'X6', 'jaune', 1);
insert into voiture values ( 'JOIZ765X', 'Dacia', 'Duster', 'gris', 4);
insert into voiture values ( 'LSQF8H7S', 'BMW', 'X4', 'marron', 1);

----------------------------------------
-- WATEL NOA
----------------------------------------
--table infraction
insert into infraction values (3035, 'classe4', 'Oublie de clignotant', '135');
insert into infraction values (6667, 'classe4', 'Non respect du temp arret au panneau STOP', '135');
insert into infraction values (2508, 'classe4', 'Non payement du stationnement', '135');
insert into infraction values (9648, 'classe4', 'Conduite dangereuse', '135');
insert into infraction values (59, 'classe4', 'Non port de la ceinture de sécurité', '135');
insert into infraction values (4957, 'classe4', 'Port de sandale en conduisant', '135');
insert into infraction values (2048, 'classe4', 'Stationnement gênant', '135');
insert into infraction values (9995, 'classe4', 'Stationnement très gênant', '135');
insert into infraction values (9784, 'classe4', 'Stationnement sur une place handicapé', '135');
insert into infraction values (6542, 'classe4', 'Controle technique non valide', '135');
insert into infraction values (9823, 'classe4', 'Pneu lisse', '135');

----
--JULES BENARD
-----

--table voiture
insert into voiture values ( 'JDZIAQHF', 'Mercedes-Benz', 'Class A45S AMG', 'jaune', 7);
insert into voiture values ( 'FQZEFH54', 'Mercedes-Benz', 'GLE 2021', 'vert mat', 5);
insert into voiture values ( '3TQEZDJJ', 'Mercedes-Benz', 'GT63S', 'noir mat', 8);
insert into voiture values ( '5FQSDJQ2', 'Mercedes-Benz', 'GLA', 'rouge', 9);

--table infraction
insert into infraction values (2943, 'classe4', 'Assurance périmé', '22');
insert into infraction values (3813, 'classe4', 'Ligne blanche continue depassé', '135');
insert into infraction values (4328, 'classe4', 'Excés de vitesse +20km/h', '135');
insert into infraction values (8403, 'classe4', 'Non port de la ceinture de sécurité', '90');
insert into infraction values (2984, 'classe4', 'Non-paiement d´un péage', '135');
insert into infraction values (4568, 'classe4', 'Dispositifs de freinage non conformes', '135');



insert into commettre values ( 'OR333DI', 17, 2943, '12-02-2016' );
insert into commettre values ( 'WI111FI', 17, 3813, '21-04-2003' );
insert into commettre values ( 'ZSP5CLQ4', 14, 6667, '29-10-2001' );

----------------------------------------
--CZARKOWSKI Matthieu
----------------------------------------

insert into commettre values ('AA123BB', 12,503, NOW());
insert into commettre values ('WI111FI', 14,942, NOW());
insert into commettre values ('PD123MD', 7,3251,'12-12-2012');
insert into commettre values ('R4T1OLL', 3,9648, '13-08-2022');
insert into commettre values ('LSQF845S', 2,59, '22-03-2022');
insert into commettre values ('CD854LP', 2,2233, '06-09-2016');
insert into commettre values ('D65ZFDPF', 1,9647, '01-01-2015');
insert into commettre values ('JHEZJ65X', 9,2233, '14-12-2020');
insert into commettre values ('CD854LP', 16,942, '19-05-1969');
insert into commettre values ('JHEZJ65X', 10,503, '04-06-2021');
insert into commettre values ('CV555OG', 4,6542, '26-06-2021');


----------------------------------------
--MOURONVAL Laurane
----------------------------------------

-- table propriétaire
insert into proprietaire values (248, 'Anne', 'Héantie', 'Samer');
insert into proprietaire values (124, 'Jacques', 'Célères', 'Socx');

-- table situation
insert into situation values (18, 'Parking de l||'||'IUT');
insert into situation values (19, 'Hotel de ville');
insert into situation values (20, 'Carrefour');
insert into situation values (21, 'Lycee Coubertin');

-- table voiture
insert into voiture values ( 'CH248AT', 'Fiat', 'multipla', 'kaki', 2);
insert into voiture values ( 'PA636IN', 'Porsche', '944 S', 'rouge', 17);
insert into voiture values ( 'QQ123PT', 'Renault', 'scenic', 'bleu', 248);
insert into voiture values ( 'FJ753DE', 'Peugeot', '206', 'blanche', 124);

----------------------------------------
--BUATHIER TOM
----------------------------------------

--table proprietaire
insert into proprietaire values (231, 'marc', 'marc', 'montreux');
insert into proprietaire values (432, 'melenchon', 'jean-luc', 'paris');
insert into proprietaire values (251, 'hugo', 'gilleron', 'wimereux');
insert into proprietaire values (322, 'quentin', 'halo', 'samer');
insert into proprietaire values (421, 'marina', 'pablo', 'new york');
insert into proprietaire values (323, 'hermes', 'elon', 'athenes');

--table voiture
insert into voiture values ( 'CLGHKOFD', 'citroen', 'C3', 'blanche', 2);
insert into voiture values ( '5D8F587S', 'BMW', 'M4', 'noir', 1);
insert into voiture values ( 'JOIZ734X', 'Dacia', 'sandero', 'marron', 4);
insert into voiture values ( 'LSCN8H7S', 'mercedes', 'amg', 'grise', 5);


----------------------------------------
--Hallot Hugo
----------------------------------------
-- table proprietaire
insert into proprietaire values (6969, 'marc', 'dutroux', 'Nice');
insert into proprietaire values (6970, 'jean', 'lassalle', 'Paris');
insert into proprietaire values (6971, 'pedro', 'claro', 'Paris');

-- table voiture
insert into voiture values ( 'OR323DI', 'FIAT', 'multipla', 'rouge', 6969);
insert into voiture values ( 'GERG3GH', 'fiat', 'multipla', 'rouge', 6970);

--table situation
insert into situation values (6969, 'Gare de Lilles');
insert into situation values (6970, 'Theatre');
insert into situation values (6971, 'Piscine');

--table infraction
insert into infraction values (22233, 'classe2', 'Non-paiement un peage ;', '75');

--table commettre 
insert into commettre values ('OR323DI', 6969,22233,'02-03-2420');


-----------------------------------------
-- BUGNON Lucas
-----------------------------------------

-- table situation 

insert into situation values (28, 'Plage de Calais');
insert into situation values (29, 'A26');
insert into situation values (30, 'Parking Cité Europe');
insert into situation values (31, 'Lycée Sophie Berthelot');

-- table commettre 

insert into commettre values('CH248AT', 28, 3813, '12-01-2022');
insert into commettre values('QQ123PT', 20, 4568, '04-12-2021');
insert into commettre values('FJ753DE', 30, 8403, '25-12-2020');
insert into commettre values('PA636IN', 18, 9995, '01-03-2022');
insert into commettre values('JDZIAQHF', 19, 6542, '24-03-2022');
insert into commettre values('5FQSDJQ2', 31, 4328, '19-05-2021');

-----------------------------------------
-- PAP Alexandre
-----------------------------------------

--table proprietaire
insert into proprietaire values (312, 'Roussy', 'Charles', 'calais');
insert into proprietaire values (220, 'Vanda', 'Georges', 'washington');
insert into proprietaire values (406, 'Herlock', 'Laurent', 'grande synthe');
insert into proprietaire values (240, 'Dauchot', 'Prat', 'saint omer');
insert into proprietaire values (321, 'Montrueu', 'Stephane', 'longuenesse');
insert into proprietaire values (254, 'Gorzo', 'Andre', 'dunkerque');

--table voiture
insert into voiture values ( 'LAKZLAZN', 'ALFA ROMEO', '75', 'blanche', 3);
insert into voiture values ( 'JAHZHE67', 'AIXAM', '500', 'grise', 5);
insert into voiture values ( 'IZAOZUE8', 'AIXAM', 'Crossline', 'bleue', 1);
insert into voiture values ( 'AMZLZO2E', 'ABARTH', '124', 'verte', 4);




----------------------------------------
--Gilleron Quentin
----------------------------------------
-- table proprietaire
insert into proprietaire values (548, 'Jule', 'Romeo', 'Lille');
insert into proprietaire values (568, 'jean', 'Fala', 'Paris');
insert into proprietaire values (485, 'pedro', 'Ivala', 'Paris');

-- table voiture
insert into voiture values ( 'OP324DI', 'audi', 'RS3', 'noir', 548);
insert into voiture values ( 'GCRG8GK', 'fiate', 'multipla', 'beige', 568);

--table situation
insert into situation values (548, 'Piscine');
insert into situation values (568, 'Theatre');
insert into situation values (485, 'Gare du Nord');

--table infraction
insert into infraction values (22243, 'classe3', 'Ecces de vitesse de plus de 25 km/h;', '135');

--table commettre 
insert into commettre values ('OP324DI', 548,22243,'14-06-2021');





-----------------------------------------
--           Houssam CUMZAIN           --
-----------------------------------------

-- table proprietaire
insert into proprietaire values (8000, 'Julien', 'Lang', 'Dunkerque');
insert into proprietaire values (8001, 'Abby', 'Campbell', 'Dunkerque');
insert into proprietaire values (8002, 'Houssam', 'Cumzain', 'Dunkerque');

-- table voiture
insert into voiture values ('PK48AF6', 'Audi', 'A3', 'noir', 8000);
insert into voiture values ('TC13RE8', 'Fiat', 'Multipla', 'rouge', 8001);
insert into voiture values ('LX69PD6', 'Citroen', 'C4', 'gris', 8002);

--table situation
insert into situation values (8000, 'Stade');
insert into situation values (8001, 'Mairie');
insert into situation values (8002, 'Gare de Dunkerque');

--table commettre 
insert into commettre values ('PK48AF6',8000,2548,'02-03-2420');
insert into commettre values ('TC13RE8',8001,0345,'02-03-2420');





