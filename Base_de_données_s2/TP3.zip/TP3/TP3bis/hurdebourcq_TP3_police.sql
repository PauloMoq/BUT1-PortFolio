/*TP3 bis Hurdebourcq Paul*/

/*Q1*/
Partie 1 :
Q1 :
SELECT pro_nom, inf_prix FROM proprietaire 
INNER JOIN voiture ON proprietaire.pro_id = voiture.pro_id 
INNER JOIN commettre ON voiture.voi_immatriculation = commettre.voi_immatriculation 
INNER JOIN infraction ON commettre.inf_numero = infraction.inf_numero 
WHERE infraction.inf_prix 
IN (SELECT(MAX(inf_prix)) 
FROM infraction);

 pro_nom | inf_prix
---------+----------
 Xina    |    75000
 Claude  |    75000
(2 lignes)


/*Q2*/
Q2 :
SELECT inf_libelle, sit_lieu FROM infraction
INNER JOIN commettre ON commettre.inf_numero = infraction.inf_numero 
INNER JOIN voiture ON voiture.voi_immatriculation=commettre.voi_immatriculation 
INNER JOIN situation ON commettre.sit_id = situation.sit_id
WHERE pro_id 
IN (SELECT pro_id FROM proprietaire WHERE UPPER(pro_prenom) LIKE 'REMI' AND UPPER(pro_nom) LIKE 'SYNAVE');

          inf_libelle           |    sit_lieu
--------------------------------+-----------------
 Ligne blanche continue depassé | Plage de Calais
(1 ligne)

/*Q3*/
Q3 :
SELECT voiture.voi_immatriculation, ROUND(AVG(inf_prix)) FROM infraction 
INNER JOIN commettre ON infraction.inf_numero = commettre.inf_numero 
INNER JOIN voiture ON commettre.voi_immatriculation = voiture.voi_immatriculation 
WHERE voiture.voi_immatriculation 
LIKE '%P%' 
GROUP BY voiture.voi_immatriculation;

 voi_immatriculation | round
---------------------+-------
 QQ123PT             |   135
 PD123MD             |   103
 75PM8962            |    35
 OP324DI             |   135
 ZSP5CLQ4            |   135
 CD854LP             | 37538
 PA636IN             |   135
 D65ZFDPF            |   244
 PK48AF6             |    35
(9 lignes)

/*Q4*/
Q4 :
SELECT voiture.voi_immatriculation, SUM(inf_prix) FROM infraction 
INNER JOIN commettre ON infraction.inf_numero = commettre.inf_numero 
INNER JOIN voiture ON commettre.voi_immatriculation = voiture.voi_immatriculation
GROUP BY voiture.voi_immatriculation;

 voi_immatriculation |  sum
---------------------+-------
 JHEZJ65X            |    75
 QQ123PT             |   135
 CH248AT             |   135
 OR333DI             |    97
 FJ753DE             |    90
 5FQSDJQ2            |   135
 R4T1OLL             |   135
 PD123MD             |   205
 75PM8962            |    35
 OP324DI             |   135
 ZSP5CLQ4            |   405
 AA123BB             |    38
 LSQF845S            |  2190
 JDZIAQHF            |   135
 WI111FI             | 75135
 OR323DI             |    75
 CD854LP             | 75075
 CLC1SD53            |   585
 PA636IN             |   135
 D65ZFDPF            |  1465
 CV555OG             |   135
 PK48AF6             |    35
(22 lignes)

/*Q5*/
Q5 :
SELECT proprietaire.pro_id, SUM(inf_prix) FROM infraction 
INNER JOIN commettre ON infraction.inf_numero = commettre.inf_numero 
INNER JOIN voiture ON commettre.voi_immatriculation = voiture.voi_immatriculation 
INNER JOIN proprietaire ON voiture.pro_id = proprietaire.pro_id 
WHERE inf_prix>1000 
GROUP BY proprietaire.pro_id;

 pro_id |  sum
--------+-------
      3 | 75000
      7 | 75000
      1 |  1500
(3 lignes)

/*Q6*/
Q6 :
SELECT proprietaire.pro_nom FROM proprietaire 
INNER JOIN voiture ON voiture.pro_id=proprietaire.pro_id
WHERE voiture.voi_immatriculation 
IN (SELECT voiture.voi_immatriculation FROM voiture  
INNER JOIN commettre ON commettre.voi_immatriculation=voiture.voi_immatriculation
INNER JOIN infraction ON commettre.inf_numero = infraction.inf_numero 
WHERE infraction.inf_categorie LIKE 'classe1');

  pro_nom
-----------
 capitaine
 Julien
 Wok
(3 lignes)

/*Q7*/
Q7 : 

SELECT p.pro_nom, sum(inf_prix) from infraction as i 
inner join commettre as c on c.inf_numero = i.inf_numero 
inner join voiture as v on v.voi_immatriculation = c.voi_immatriculation 
inner join proprietaire 
as p on p.pro_id = v.pro_id 
group by p.pro_nom 
having sum(inf_prix) >= all (select (sum(inf_prix)) from infraction as i 
inner join commettre as c 
on c.inf_numero = i.inf_numero 
inner join voiture as v on v.voi_immatriculation = c.voi_immatriculation 
inner join proprietaire as p on p.pro_id = v.pro_id 
group by p.pro_nom);

 pro_nom |  sum
---------+-------
 Xina    | 77125
(1 ligne)



/*Q1*/
Partie 2 :
Q1 :

CREATE or REPLACE VIEW details_infractions (inf_numero,voi_immatriculation) 
as SELECT * FROM 
infraction I 
INNER JOIN commettre C 
on I.inf_numero=C.inf_numero 
INNER JOIN voiture V
on C.voi_immatriculation=V.voi_immatriculation;

CREATE VIEW

/*Q2*/
Q2 :
create or replace view total_infraction_payee_par_proprietaire (pro_nom, total) 
as SELECT p.pro_nom, sum(inf_prix) 
FROM infraction as i 
INNER JOIN commettre 
as c 
on c.inf_numero = i.inf_numero 
INNER JOIN voiture as v 
on v.voi_immatriculation = c.voi_immatriculation 
INNER JOIN proprietaire 
as p 
on p.pro_id = v.pro_id 
GROUP BY p.pro_nom;

CREATE VIEW

/*Q1*/
Partie 3 : 
Q1 :
CREATE OR REPLACE VIEW details_infractions 
as SELECT I.inf_libelle 
AS crime, S.sit_lieu 
AS lieu 
FROM infraction 
AS I 
INNER JOIN commettre 
AS C 
ON C.inf_numero = I.inf_numero 
INNER JOIN voiture 
AS V 
ON V.voi_immatriculation=C.voi_immatriculation 
INNER JOIN situation 
AS S 
ON C.sit_id = S.sit_id
WHERE V.pro_id 
IN (SELECT pro_id FROM proprietaire WHERE UPPER(pro_prenom) LIKE 'REMI' AND UPPER(pro_nom) LIKE 'SYNAVE');

CREATE VIEW

police=# SELECT * FROM details_infractions;
          crime           |  lieu
--------------------------------+-----------------
 Ligne blanche continue depassé | Plage de Calais
(1 row)

/*Q2*/ 
Q2 :
create or replace view details_infraction 
as SELECT V.voi_immatriculation 
AS plaque, ROUND(AVG(inf_prix)) 
AS moyenne 
FROM infraction I 
INNER JOIN commettre C 
ON I.inf_numero = C.inf_numero 
INNER JOIN voiture V 
ON C.voi_immatriculation 
= V.voi_immatriculation 
WHERE V.voi_immatriculation 
LIKE 'JAIME-LE-JAVA' 
GROUP BY V.voi_immatriculation;

CREATE VIEW

/*Q3*/
Q3 :

SELECT voi_immatriculation, voi_marque, voi_modele, sum(inf_prix) 
as total_amende 
FROM details_infractions
GROUP BY voi_immatriculation, voi_marque, voi_modele;

 voi_immatriculation |  voi_marque   |      voi_modele      | total_amende 
---------------------+---------------+----------------------+--------------
 QQ123PT             | Renault       | scenic               |          135
 5FQSDJQ2            | Mercedes-Benz | GLA                  |          135
 LSQF845S            | BMW           | serie 3 e36          |         2190
 PA636IN             | Porsche       | 944 S                |          135
 CV555OG             | renault       | Clio                 |          135
 OR333DI             | porsche       | Boxster 987          |           97
 FJ753DE             | Peugeot       | 206                  |           90
 PD123MD             | fiat          | Multipla             |          205
 ZSP5CLQ4            | Toyota        | Supra MK4            |          405
 CD854LP             | ferrari       | Daytona SP3          |        75075
 CLC1SD53            | Citroen       | Xantia EXCLUSIVE     |          585
 CH248AT             | Fiat          | multipla             |          135
 75PM8962            | ferrari       | Ferrari Daytona SP3  |           35
 OP324DI             | audi          | RS3                  |          135
 WI111FI             | citroen       | Cactus               |        75135
 PK48AF6             | Audi          | A3                   |           35
 JHEZJ65X            | Porsche       | 911 GT2RS            |         1575
 R4T1OLL             | citroen       | c3 picasso           |          135
 AA123BB             | lada          | lada2107             |          788
 JDZIAQHF            | Mercedes-Benz | Class A45S AMG       |          135
 OR323DI             | FIAT          | multipla             |           75
 D65ZFDPF            | Ford          | Mustang Shelby GT500 |         1465
(22 rows)

/*Q4*/
Q4 :

SELECT pr.pro_nom, d_inf.voi_immatriculation, d_inf.inf_libelle, si.sit_lieu, d_inf.date_heure 
FROM details_infractions d_inf
INNER JOIN proprietaire pr 
on pr.pro_id = d_inf.pro_id
INNER JOIN situation si 
on si.sit_id = d_inf.sit_id
where (d_inf.inf_libelle 
like 'Conduite en état d’ivresse' 
or d_inf.inf_libelle 
like 'Conduite en état alcoolique') 
and si.sit_lieu 
like 'place d||armes' 
and d_inf.date_heure = '2010/01/01';

 pro_nom | voi_immatriculation | inf_libelle | sit_lieu | date_heure 
---------+---------------------+-------------+----------+------------
(0 rows)

/*Q1*/
Partie 4 :
Q1 :

create or replace view proprietaires_calais 
as SELECT * FROM proprietaire
where pro_ville 
like 'calais' 
or pro_ville 
like 'Calais';

CREATE VIEW

/*Q2*/
Q2 :

create or replace view somme_amende_par_voiture 
as SELECT voi_immatriculation, voi_marque, voi_modele, sum(inf_prix) 
as total_amende 
FROM details_infractions
GROUP BY voi_immatriculation, voi_marque, voi_modele;

CREATE VIEW

/*Q3*/
Q3 :

create or replace view moyenne_amende_par_proprietaire 
as SELECT pr.*, round(avg(inf.inf_prix)) 
as avg_amende 
FROM proprietaire pr
INNER JOIN voiture vo 
on vo.pro_id = pr.pro_id
INNER JOIN commettre co 
on co.voi_immatriculation = vo.voi_immatriculation
INNER JOIN infraction inf 
on inf.inf_numero = co.inf_numero
GROUP BY pr.pro_id;

CREATE VIEW

/*Q4*/
Q4 :

create or replace view situations_calais 
as select * from situation
where sit_lieu 
like '%Calais%' 
or sit_lieu 
like '%calais%';

CREATE VIEW

/*Q5*/
Q5 :

create or replace view voiture_grises 
as select * from voiture
where voi_couleur 
like 'gris%';

CREATE VIEW

/*Q6*/