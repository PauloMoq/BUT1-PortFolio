-- Creation des tables de la database police
-- Monsieur CAPITAINE
-- BUT 1 informatique
-- avril 2022


CREATE TABLE situation(
   sit_id INT,
   sit_lieu VARCHAR(50),
   PRIMARY KEY(sit_id)
);

CREATE TABLE infraction(
   inf_numero INT,
   inf_categorie VARCHAR(50),
   inf_libelle VARCHAR(50),
   inf_prix INT,
   PRIMARY KEY(inf_numero)
);

CREATE TABLE proprietaire(
   pro_id INT,
   pro_nom VARCHAR(50),
   pro_prenom VARCHAR(50),
   pro_ville VARCHAR(50),
   PRIMARY KEY(pro_id)
);

CREATE TABLE voiture(
   voi_immatriculation VARCHAR(50),
   voi_marque VARCHAR(50),
   voi_modele VARCHAR(50),
   voi_couleur VARCHAR(50),
   pro_id INT NOT NULL,
   PRIMARY KEY(voi_immatriculation),
   FOREIGN KEY(pro_id) REFERENCES proprietaire(pro_id)
);

CREATE TABLE commettre(
   voi_immatriculation VARCHAR(50),
   sit_id INT,
   inf_numero INT,
   date_heure DATE,
   PRIMARY KEY(voi_immatriculation, sit_id, inf_numero),
   FOREIGN KEY(voi_immatriculation) REFERENCES voiture(voi_immatriculation),
   FOREIGN KEY(sit_id) REFERENCES situation(sit_id),
   FOREIGN KEY(inf_numero) REFERENCES infraction(inf_numero)
);
