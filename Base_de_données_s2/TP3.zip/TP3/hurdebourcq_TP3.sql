/*TP3 Hurdebourcq Paul*/

/*Q1*/
Q1 : Créez une vue NOTE_ANGLAIS qui donne le numéro d’épreuve, le nom d l’épreuve, le nom de l’étudiant et 
la note pour la matière ANGLAIS.
create or replace view NOTE_ANGLAIS as select etudiants.nometu,epreuves.libepr,epreuves.numepr,avoir_note.note from etudiants inner join avoir_note on etudiants.numetu = avoir_note.numetu inner join epreuves on avoir_note.numepr = epreuves.numepr where libepr ='interro anglais';

CREATE VIEW

/*Q2*/
Q2 : Consultez cette vue. Observez la table pg_views.
\d pg_views;
select * from pg_views where viewname='NOTE_ANGLAIS';

postgres=# select * from pg_views where viewname='NOTE_ANGLAIS';
 schemaname | viewname | viewowner | definition
------------+----------+-----------+------------
(0 ligne)

/*Q3*/
Q3 : Pouvez-vous insérer un tuple dans cette vue ?
insert into note_anglais values (1, 'anglais', 'robl', 17);
|-> error car la view représente le résultat d_une requête et non une table que l_on pourrait modifier

ERREUR:  syntaxe en entrée invalide pour le type integer : « robl »
LIGNE 1 : insert into note_anglais values (1, 'anglais', 'robl', 17);

/*Q4*/
Q4 : Créez une vue ETUDIANT_1 des étudiants de première année
create or replace view ETUDIANT_1 as select * from etudiants where annetu=1;

CREATE VIEW

/*Q5*/
Q5: Créez une vue TUTEUR_POS des enseignants qui habitent la même ville qu’un étudiant. Son contenu sera 
nom étudiant, nom enseignant.
create or replace view TUTEUR_POS as select nomens, nometu, vilens from enseignants, etudiants where enseignants.vilens = etudiants.viletu;

CREATE VIEW

/*Q6*/
Q6: Créez une vue MOY_MATIERE de la moyenne par étudiants par matière. Son contenu sera nom étudiant, 
nom matière, moyenne. Vous veillerez à bien exploiter le coefficient de l’épreuve.
CREATE OR REPLACE VIEW moy_matiere (nometu,nommat,moyenne) AS SELECT et.nometu, m.nommat, AVG  (a.note*ep.coefepr)/SUM (ep.coefepr) from etudiants et inner join avoir_note a ON et.numetu=a.numetu INNER JOIN epreuves ep ON a.numepr=ep.numepr INNER JOIN matieres m ON ep.matepr=m.nummat GROUP BY et.nometu, m.nummat, m.nommat;

CREATE VIEW

/*Q7*/
Q7 : Créez une vue BONS_ETUDIANTS des étudiants qui ont une moyenne supérieure à 12. On y mettra le nom 
de l’étudiant et sa moyenne.
CREATE or REPLACE VIEW BONS_ETUDIANTS (nometu,moyenne)as select nometu,moyenne FROM moy_matiere where moyenne >12;

CREATE VIEW

/*Q8*/
Q8 : A partir de cette vue, créez TRES_BONS_ETUDIANTS des moyennes supérieures à 16.
create or replace view tres_bons_etudiants as select * from bons_etudiants where moyenne>16;

CREATE VIEW

/*Q9*/
Q9 : Si vous supprimez BONS_ETUDIANTS, qu’advient-il de TRES_BONS_ETUDIANTS ?
drop view bons_etudiants;
|-> la vue bons_etudiants ne peut pas être supprimée car des objets en dépendent

Q10 : Supprimez tout de même BONS_ETUDIANTS avec la commande conseillé par postgresql. Qu_advient-il de 
TRES_BONS_ETUDIANTS ?
drop view bons_etudiants cacade;

DROP VIEW