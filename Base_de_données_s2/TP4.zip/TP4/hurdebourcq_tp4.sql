/*Hurdebourcq Paul TD1 TPB 04/05/2022*/

local : psql -d privilegebdd -h 10.10.28.106 -U
non local : psql -d privilegebdd -h 194.57.179.74 p80

1)
/* Retrouvez la commande permettant de faire apparaître l’ensemble des tables catalogue du logiciel postgresql. */
\dS

2)
/* Retrouvez la valeur du « search_path » dans les options (table pg_settings). */
show search_path;
  search_path
----------------
 "$user",public
(1 ligne)

3)
/* Cherchez la commande qui permet de lister (avec le détail!) les schémas de la base de données. */
\dn ou dn+
Liste des schÚmas
          Nom           |      PropriÚtaire
------------------------+------------------------
 adam.gilles            | adam.gilles
 aernouts.fabien        | aernouts.fabien
 amzil.marwane          | amzil.marwane

ETC.....

4)
/*  Précisez le nombre de schémas présents dans la base de données (table pg_namespace). */
table pg_namespace ;
94 lignes

5)
/* Selon vous, quels types de tables sont présentes dans le schéma pg_catalog ? */
Selon moi, pg_catalog regroupe toutes les tables système.

9)
/* Créez un schéma dont le nom sera votre login. Attention, lorsque vous utilisez un point dans un nom, le nom 
complet doit être entouré de guillements. (exemple : « capitaine.dany »). Puis recréez dans ce nouveau schéma 
une nouvelle table dont le nom sera composé de la première lettre de votre prénom suivi de votre nom. 
(Exemple de nom de table : dcapitaine).Remarque pour le propriétaire de la base de données : Il faut donner les 
privilèges au public */
privilegebdd=> create schema "hurdebourcq.paul";
CREATE SCHEMA

privilegebdd=> create table phurdebourcq() ;
CREATE TABLE
privilegebdd=> \d
                     List of relations
      Schema      |     Name     | Type  |      Owner
------------------+--------------+-------+------------------
 hurdebourcq.paul | phurdebourcq | table | hurdebourcq.paul
(1 row)

privilegebdd=> grant all on phurdebourcq to public;
GRANT

10)
/* Retrouvez de nouveau le nom du schéma dans lequel se trouve la table que vous venez de créer. Si votre 
table se trouve dans le schéma public vous pouvez recommencer l’opération. */
privilegebdd=> show search_path;
    search_path
--------------------
 "hurdebourcq.paul"
(1 row)

11)
/* Supprimez le schéma et la table qu’elle contient. */
drop schema "hurdebourcq.paul" cascade;

12)
/* Copiez les tables ETUDIANTS, ENSEIGNANTS, MATIERES, MODULES,AVOIR_NOTE, EPREUVES 
et FAIRE_COURS dans votre schéma. */
privilegebdd=> create table modules(like "capitaine.dany".modules including all);
CREATE TABLE
privilegebdd=> create table avoir_note(like "capitaine.dany".avoir_note including all);
CREATE TABLE
privilegebdd=> create table enseignants(like "capitaine.dany".enseignants including all);
CREATE TABLE
privilegebdd=> create table epreuves(like "capitaine.dany".epreuves including all);
CREATE TABLE
privilegebdd=> create table etudiants(like "capitaine.dany".etudiants including all);
CREATE TABLE
privilegebdd=> create table faire_cours(like "capitaine.dany".faire_cours including all);
CREATE TABLE
privilegebdd=> create table matieres(like "capitaine.dany".matieres including all);
CREATE TABLE

insert into avoir_note select * from "capitaine.dany".avoir_note;
INSERT 0 37
insert into modules select * from "capitaine.dany".modules
;
INSERT 0 4
insert into enseignants select * from "capitaine.dany".ens
eignants;
INSERT 0 11
insert into epreuves select * from "capitaine.dany".epreuv
es;
INSERT 0 6
insert into etudiants select * from "capitaine.dany".etudi
ants;
INSERT 0 18
insert into faire_cours select * from "capitaine.dany".fai
re_cours;
INSERT 0 24
insert into matieres select * from "capitaine.dany".matier
es;
INSERT 0 14

privilegebdd=> grant all on schema "hurdebourcq.paul" to "capitaine.dany";
GRANT
privilegebdd=> grant all on table avoir_note to "capitaine.dany";
GRANT
privilegebdd=> grant usage on schema "hurdebourcq.paul" to "capitaine.dan
y";
GRANT

privilegebdd=> grant all on avoir_note, enseignants, epreuves, etudiants, faire_cours, matieres, modules to "guarim.raphael" with grant option;
GRANT
privilegebdd=> grant all on schema "hurdebourcq.paul" to "guarim.raphael" with grant option;
GRANT

/*Hurdebourcq Paul TD1 TPB 04/05/2022*/