1) 
/* 
Renvoie le nom des schemas & table correspondante 
*/

SELECT schemaname, tablename from pg_tables

2) 
/* 
Renvoie le nom du schema pour les tables du USER
*/
SELECT schemaname, tablename from pg_tables where 
tableowner=USER;

3) 
/*
Renvoie tout les schémas
*/
SELECT * from pg_views;

4)
/*
Renvoie la totalité des schémas dans pg_indexes du USER
*/
SELECT * FROM pg_indexes WHERE tablename IN (SELECT tablename FROM pg_tables WHERE 
tableowner=USER); 

5)
/*
Renvoie la totalité des tables pour le pg_user
*/
SELECT * FROM pg_user ; 

6)
/*
Renvoie le nom des contraintes
*/
SELECT relname, conname, consrc FROM pg_class INNER JOIN pg_constraint ON relfilenode=conrelid;

7)
/*
Renvoie toutes les bases de données du USER
*/
SELECT datname, usename from pg_database inner join pg_user on datdba=usesysid where 
usename=user;

8)
/*
Renvoie les tables avec leurs propriétaires dans les schémas
*/
SELECT schemaname, tablename, tableowner FROM pg_tables;

9)
/*
Renvoie les bases de données avec leurs propriétaires & encodage.
*/
SELECT datdba, oid, datname FROM pg_database;

10)
/*
Renvoie les contraintes des tables dans le schéma information_schema.
*/
SELECT conname FROM pg_constraint AS c INNER JOIN pg_namespace AS n ON c.connamespace = n.oid INNER JOIN pg_tables AS t ON n.nspame = t.schemaname WHERE schemaname LIKE 'information_schema';

13)
/*
Renvoie la liste des noms, prénoms, âges des étudiants.
*/
SELECT nometu, prenometu, AGE(datentetu, datnaietu) FROM etudiants;

14)
/*
Renvoie la liste des noms et prénoms des étudiants (collés) et leur date de naissance.
*/
SELECT nometu || prenometu, datnaietu FROM etudiants;

15)
/*
Renvoie la question 14, mais en remplaçant les "ma" en "tu".
*/
SELECT replace(nometu || prenometu, 'ma', 'tu'), datnaietu from etudiants;

16)
/*
Renvoie le nom, prénom et note des étudiants quand leur note est supérieur à 3x pi (~= 9.5)
*/
SELECT nometu, prenometu, note FROM etudiants AS etu INNER JOIN avoir_note AS avo ON etu.numetu = avo.numetu WHERE note > pi() * 3;