//     Hurdebourcq Paul BUT1 TPB     //
//       --R2.01 TD/TP_Echec--       //
//          03-04/2022 |S2|          //
//  - Utilisation non commerciale -  //

package myChessLib.pieces;

import java.util.ArrayList;

import myChessLib.Position;
import myChessLib.*;

/**
 * [Class Piece]
 * This Class is extended from the Class Piece
 * 
 * @author Paul Hurdebourcq
 * Contact me with mail : phurdepro@gmail.com
 * Or with discord : Moqmoq#9059
 * 
 * @version 1.0
 */
public abstract class Piece {

    // attributs
    private char couleur;
    private Position position;
    
    /**
     * Constructeur par défaut
     */ 
    public Piece(){
        this.couleur = 'B';
        this.position = new Position("A2");
        }

    /**
     * Constructeur par copie
     * 
     * @param p objet de type Piece
     * @see "Piece Class"
     */
    public Piece(Piece p){
        this.couleur = p.couleur;
        this.position = p.position;
    }

    /**
     * Constructeur par valeurs
     * @param couleur1 'B' ou 'N' en fonction de la couleur de la pièce
     * @param x entier représentat le x de la position
     * @param y entier représentant le y de la position
     */
    public Piece(char couleur1, int x, int y){
        this.couleur = couleur1;
        this.position = new Position(x,y);
    }

    /**
     * Constructeur par valeurs
     * @param couleur2 'B' ou 'N' en fonction de la couleur de la pièce
     * @param position2 objet de type Position
     * @see "Position Class"
     */
    public Piece(char couleur2, Position position2){
        this.couleur = couleur2;
        this.position = new Position(position2);
    }
    
    /**
     * Constructeur par valeurs
     * @param couleur3 'B' ou 'N' en fonction de la couleur de la pièce
     * @param chaine String représentant la position sous la forme [A1...H8]
     */
    public Piece(char couleur3, String chaine){
        this.couleur = couleur3;
        this.position = new Position(chaine);
    }

    /* Getters */
    // Je précise P_ pour indiquer que la méthode provient de la classe Piece

    /**
     * Méthode getType
     * -> abstract method
     * @see "getType of mother class"
     * @return "None, it's an abstract Class"
     */    
    public abstract String getType();

    /**
     * Méthode getCouleur
     * 
     * permet de récupérer la couleur
     * @return char, 'B' or 'N'
     */
    public char getCouleur(){
        return this.couleur;
    }

    /**
     * Méthode getPosition
     * 
     * permet de récupérer la position
     * @return char, 'B' or 'N'
     */
    public Position getPosition(){
        return this.position;
    }

    /**
     * Méthode p_GetX
     * 
     * permet de récupérer la valeur x de la position
     * @return int, le x de la position
     */
    public int p_GetX(){
        return this.position.getX();
    }

    /**
     * Méthode p_GetY
     * 
     * permet de récupérer la valeur y de la position
     * @return int, le y de la position
     */
    public int p_GetY(){
        return this.position.getY();
    }



    /* Setters */

    /**
     * Méthode p_SetX
     * 
     * permet d'affecter une valeur pour x
     * @param abscisse x à affecter
     */
    public void p_SetX(int abscisse){
        this.position.setX(abscisse);
    }

    /**
     * Méthode p_SetY
     * 
     * permet d'affecter une valeur pour y
     * @param ordonnee y à affecter
     */
    public void p_setY(int ordonnee){
        this.position.setY(ordonnee);
    }

    /**
     * Méthode setPosition
     * 
     * permet d'affecter une position
     * @param position position à affecter
     */
    public void setPosition(Position position){
        this.position = new Position(position);
    }

    /**
     * Méthode setCouleur
     * 
     * permet d'affecter une couleur
     * @param couleur couleur à affecter
     */
    public void setCouleur(char couleur){
        this.couleur = couleur;
    }

    /**
     * Méthode getNomCourt
     * 
     * permet d'obtenir le nom d'une pièce en 3 caractères
     * (RoB pour roi blanc)
     * @return String, "nom en 3 caractères"
     */
    public String getNomCourt(){
        return (""+this.getType().charAt(0)+this.getType().charAt(1)+this.couleur);
    }

    /**
     * Méthode getNomLong
     * 
     * permet d'obtenir le nom d'une pièce en entier
     * (roi_b pour roi blanc)
     * @return String, "nom en entier"
     */
    public String getNomLong(){
        return (""+this.getType()+'_'+this.couleur);
    }

    /**
     * Méthode equals
     * 
     * permet de vérifier si deux objets sont identiques ou non
     */
    public boolean equals(Object truc){
        if (truc instanceof Piece == false){
            return false;
            }
        Piece p = (Piece)truc;
        /* == c'est pour les types natifs (int, double, char) alors que equals c'est pour les objects */
        return (this.couleur == p.couleur && this.position.equals(p.position));
    }

    /**
     * Méthode toString
     * 
     * permet de renvoyer une phrase en fonction d'une pièce
     */
    public String toString(){
        /* ici j'ai du utiliser la méthode abstraite getType() à la place de self.type */
        if (this.couleur == 'B'){
            return (this.getType()+" blanc en "+this.position.toString());
            }
        else {
            return (this.getType()+" noir en "+this.position.toString());
            }
    }

    /**
     * Méthode getDeplacementPossible
     * -> abstract method
     * @see "getDeplacementPossible of mother class"
     * @param jeu plateau de jeu non graphique
     * @return "None, it's an abstract Class"
     */
    public abstract ArrayList<Position> getDeplacementPossible(Plateau jeu);

    /*   
      |x| L'attribut type a bien été supprimé de la classe 
    */
}

//     Hurdebourcq Paul BUT1 TPB     //
//       --R2.01 TD/TP_Echec--       //
//          03-04/2022 |S2|          //
//  - Utilisation non commerciale -  //