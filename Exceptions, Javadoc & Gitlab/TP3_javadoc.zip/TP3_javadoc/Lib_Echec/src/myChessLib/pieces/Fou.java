//     Hurdebourcq Paul BUT1 TPB     //
//       --R2.01 TD/TP_Echec--       //
//          03-04/2022 |S2|          //
//  - Utilisation non commerciale -  //

package myChessLib.pieces;

import myChessLib.*;
import java.util.ArrayList;

/**
 * [Class Fou]
 * This Class is extended from the Class Piece
 * 
 * @author Paul Hurdebourcq
 * Contact me with mail : phurdepro@gmail.com
 * Or with discord : Moqmoq#9059
 * 
 * @version 1.0
 */
public class Fou extends Piece{

    /**
     * Constructeur par défaut
     */ 
    public Fou(){
        super();
    }

    /**
     * Constructeur par valeurs
     * 
     * @param couleur 'B' ou 'N' en fonction de la couleur de la pièce
     * @param pos objet de type Position
     * @see "Position Class"
     */
    public Fou(char couleur, Position pos){
        super(couleur, pos);
    }

    /**
     * Méthode getType
     * @see "getType of mother class"
     * @return String, "fou"
     */
    @Override
    public String getType() {
        return "fou";
    }

    /**
     * Méthode getDeplacementPossible
     * @see "getDeplacementPossible of mother class"
     * @param jeu plateau de jeu non graphique
     * @return ArrayList, DeplaPossibles : liste de tous les déplacements disponibles
     */
    @Override
    public ArrayList<Position> getDeplacementPossible(Plateau jeu) {
        ArrayList<Position> deplaPossibles = new ArrayList<Position>();
        Position position = new Position(this.getPosition());

        // Diagonales haut
        /* Haut et droite */
        for (int i=1; i < 9; i++){
            if (position.getX() + i < 8 && position.getX() + i >= 0 && position.getY() + i >= 0 && position.getY() + i < 8){
                Position posHD = new Position((position.getX() + i ), (position.getY() + i ));
                if (jeu.getCase(posHD) != null && jeu.getCase(posHD).getCouleur() == this.getCouleur()){
                    break;
                }
                if(jeu.getCase(posHD) == null){
                    deplaPossibles.add(posHD);
                }
                if(jeu.getCase(posHD) != null && jeu.getCase(posHD).getCouleur() != this.getCouleur()){
                    deplaPossibles.add(posHD);
                    break;
                }
                
            }   
        }

        /* Haut et gauche */
        for (int i=1; i < 9; i++){
            if (position.getX() - i < 8 && position.getX() - i >= 0 && position.getY() + i >= 0 && position.getY() + i < 8){
                Position posHG = new Position(( position.getX() - i ),( position.getY() + i ));
                if(jeu.getCase(posHG) != null && jeu.getCase(posHG).getCouleur() == this.getCouleur()){
                    break;
                }
                if(jeu.getCase(posHG) == null){
                    deplaPossibles.add(posHG);
                }
                if (jeu.getCase(posHG) != null && jeu.getCase(posHG).getCouleur() != this.getCouleur()){
                    deplaPossibles.add(posHG);
                    break;
                }
                
            }
        }





        // Diagonales bas
        /* Bas et gauche */
        for (int i=1; i < 9; i++){
            if (position.getX() - i < 8 && position.getX() - i >= 0 && position.getY() - i >= 0 && position.getY() - i < 8){
                Position posBG = new Position(( position.getX() - i ),( position.getY() - i ));
                if(jeu.getCase(posBG) != null && jeu.getCase(posBG).getCouleur() == this.getCouleur()){
                    break;
                } 
                if(jeu.getCase(posBG) == null ){
                    deplaPossibles.add(posBG);
                }   
                if(jeu.getCase(posBG) != null && jeu.getCase(posBG).getCouleur() != this.getCouleur()){
                    deplaPossibles.add(posBG);
                    break;
                }
            }
        }

        /* Bas et droite */
        for (int i=1; i < 9; i++){
            if (position.getX() + i < 8 && position.getX() + i >= 0 && position.getY() - i >= 0 && position.getY() - i < 8){
                Position posBD = new Position(( position.getX() + i ),( position.getY() - i ));
                if(jeu.getCase(posBD) != null && jeu.getCase(posBD).getCouleur() == this.getCouleur()){
                    break;
                }
                if(jeu.getCase(posBD) == null){
                deplaPossibles.add(posBD);
                }
                if (jeu.getCase(posBD) != null && jeu.getCase(posBD).getCouleur() != this.getCouleur()){
                    deplaPossibles.add(posBD);
                    break;
                }
                
            }
        }

        /* on renvoie le tableau contenant les déplacements disponibles du fou */
        return deplaPossibles;
    }   
}

//     Hurdebourcq Paul BUT1 TPB     //
//       --R2.01 TD/TP_Echec--       //
//          03-04/2022 |S2|          //
//  - Utilisation non commerciale -  //