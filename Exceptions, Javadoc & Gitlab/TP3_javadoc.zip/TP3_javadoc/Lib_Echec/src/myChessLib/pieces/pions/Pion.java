//     Hurdebourcq Paul BUT1 TPB     //
//       --R2.01 TD/TP_Echec--       //
//          03-04/2022 |S2|          //
//  - Utilisation non commerciale -  //

package myChessLib.pieces.pions;
import myChessLib.*;
import myChessLib.pieces.Piece;

import java.util.ArrayList;

/**
 * [Class Pion]
 * This Class is extended from the Class Piece
 * 
 * @author Paul Hurdebourcq
 * Contact me with mail : phurdepro@gmail.com
 * Or with discord : Moqmoq#9059
 * 
 * @version 1.0
 */
public abstract class Pion extends Piece {

    /**
     * Constructeur par défaut
     */
    public Pion(){
        super(); // appelle le constructeur par défaut de Piece
    }
    
    /**
     * Constructeur par valeurs
     * 
     * @param couleur 'B' ou 'N' en fonction de la couleur de la pièce
     * @param pos objet de type Position
     * @see "Position Class"
     */
    public Pion(char couleur, Position pos){
        super(couleur, pos);
    }

    /**
     * Méthode getType
     * -> abstract method
     * @see "getType of daughter class"
     */
    public abstract String getType();

    /**
     * Méthode getDeplacementPossible
     * -> abstract method
     * @see "getDeplacementPossible of daughter class"
     * @param jeu plateau de jeu non graphique
     */
    @Override
    public abstract ArrayList<Position> getDeplacementPossible(Plateau jeu);
}

//     Hurdebourcq Paul BUT1 TPB     //
//       --R2.01 TD/TP_Echec--       //
//          03-04/2022 |S2|          //
//  - Utilisation non commerciale -  //