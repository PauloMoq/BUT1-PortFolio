## src
Dans src => tous les fichiers : - .java  
                                - .class 
                                - dossier images

## lib
Dans lib => toutes les librairies : - MG2D

## Travail de Paul Hurdebourcq TPB TD1