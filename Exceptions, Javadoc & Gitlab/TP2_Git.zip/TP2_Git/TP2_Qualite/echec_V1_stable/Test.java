public class Test {
    public static void main(String[] args){
        try{
            Position a=new Position("A1");
            a.setX(56);
        } catch (Exception e){
            e.printStackTrace();
            System.exit(1);
        }
    }
}
