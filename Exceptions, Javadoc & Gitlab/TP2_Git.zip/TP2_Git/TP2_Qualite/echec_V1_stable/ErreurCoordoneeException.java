class ErreurCoordoneeException extends RuntimeException {
    private int x, y;
    private String chaine;

    public ErreurCoordoneeException(int a, int b){
        super(""+"Les coordonnées : - "+a+" - "+b+" ne sont pas valides");
    }

    public ErreurCoordoneeException(String texte){
        super("Les coordonnées : "+texte+" ne sont pas valides");
    }

    public ErreurCoordoneeException(int x){
        super("Les coordonnées : "+x+" ne sont pas comprises dans l'intervalle admis");
    }

    
}
