public class RoiNonTrouveException extends RuntimeException{
    
    public RoiNonTrouveException(){
        super("Roi non trouvé sur le plateau");
    }
}
