class CaseOccupeeException extends RuntimeException {
    
    public CaseOccupeeException(Position p){
        super("La case " +p + " est deja occupé");
    }
}