public class ErreurDeplacementException extends RuntimeException{
    
    public ErreurDeplacementException(){
        super("Erreur lors du deplacement ");
    }
}
