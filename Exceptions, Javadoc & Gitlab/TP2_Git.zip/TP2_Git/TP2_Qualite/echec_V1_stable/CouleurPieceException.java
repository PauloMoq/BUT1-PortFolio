public class CouleurPieceException extends RuntimeException{
    public CouleurPieceException(char couleur){
        super("La couleur " +couleur + " n'est pas une couleur valide");
    }
}
