/*
   +--HURDEBOURCQ PAUL--+
   --TP6 BDD 16/05 | S2--
   +------TD1=>TPB------+

Question 1 : 
Créer une requête qui affichera les noms de stade dans les lesquels se sont déroulés des matchs 
ayant eu plus de 5000 spectateurs.

*/

postgres=# select nom_stade as nom, id_match as match, nbre_spectateurs as spectateurs from match inner join stade on match.id_stade = stade.id_stade where nbre_spectateurs > 5000;
          nom           | match | spectateurs
------------------------+-------+-------------
(40 lignes)

/*

Question 2 :
Donner les noms des joueurs et le nombre de buts inscrits par chacun d'entre eux.

*/

postgres=# select nom, prenom, count(but) as nb_buts from but inner join personne on but.id_personne = personne.id_personne group by personne.prenom, personne.nom;
   nom   | prenom  | nb_buts
---------+---------+---------
(2 lignes)

/*

Question 3 :
Donner les noms des joueurs qui n'ont pas marqué de but. 
Bonus : Expliquez pourquoi cette requête ne peut pas fonctionner avec la méthode inner join.

*/

postgres=# select nom, prenom from personne where id_personne not in(select id_personne from but);
      nom       |       prenom
----------------+--------------------
(100 lignes)

/*

Bonus :
Le inner join ne permet pas de vérifier l'égalité d'éléments NON présents dans une table.

*/

/* 

Question 4 :
Affichez les id_personnes qui ont une moyenne de note par match supérieure à 5/10. (Vous pourrez utiliser au choix un AVG ou faire le calcul).

*/

postgres=# select nom, prenom, round(avg(note)) as note_sur_10, id_match match from evaluer inner join personne on personne.id_personne = evaluer.id_personne where evaluer.note > 5 group by personne.nom, personne.prenom, evaluer.id_match;
   nom    | prenom  | note_sur_10 | match
----------+---------+-------------+-------
(3 lignes)

/* 

Question 5 :
Créer une vue qui aura comme nom 'joueurs_match_lens_paris' qui affichera tous les joueurs ayant participé au match opposant paris qui se déplace sur la pelouse de la merveilleuse et talentueuse équipe de Lens.

*/

postgres=# create or replace view joueurs_match_lens_paris as
postgres-# select eq.nom_equipe, pe.nom, pe.prenom from match ma
postgres-# inner join jouer_dans jo on jo.id_equipe = ma.id_equipe_recoit
postgres-# inner join personne pe on pe.id_personne = jo.id_personne
postgres-# inner join equipe eq on eq.id_equipe = jo.id_equipe
postgres-# where ma.id_equipe_recoit = (
postgres(#     select distinct ma.id_equipe_recoit from match ma
postgres(#     inner join equipe eq on eq.id_equipe = ma.id_equipe_recoit
postgres(#     where nom_equipe like 'LENS'
postgres(# )
postgres-# and ma.id_equipe_deplace = (
postgres(#     select distinct ma.id_equipe_deplace from match ma
postgres(#     inner join equipe eq on eq.id_equipe = ma.id_equipe_deplace
postgres(#     where nom_equipe like 'PARIS'
postgres(# )
postgres-# union
postgres-# select eq.nom_equipe, pe.nom, pe.prenom from match ma
postgres-# inner join jouer_dans jo on jo.id_equipe = ma.id_equipe_deplace
postgres-# inner join personne pe on pe.id_personne = jo.id_personne
postgres-# inner join equipe eq on eq.id_equipe = jo.id_equipe
postgres-# where ma.id_equipe_recoit = (
postgres(#     select distinct ma.id_equipe_recoit from match ma
postgres(#     inner join equipe eq on eq.id_equipe = ma.id_equipe_recoit
postgres(#     where nom_equipe like 'LENS'
postgres(# )
postgres-# and ma.id_equipe_deplace = (
postgres(#     select distinct ma.id_equipe_deplace from match ma
postgres(#     inner join equipe eq on eq.id_equipe = ma.id_equipe_deplace
postgres(#     where nom_equipe like 'PARIS'
postgres(# );
CREATE VIEW
postgres=# select * from joueurs_match_lens_paris order by nom_equipe, nom;
 nom_equipe |   nom    |       prenom
------------+----------+--------------------
 LENS       | MANDANDA | Steve
 LENS       | PAYET    | Dimitri
 LENS       | RAMI     | Adil
 LENS       | THAUVIN  | Florian
 LENS       | VACHOUX  | Jérémy
 PARIS      | CAVANI   | Edinson
 PARIS      | DI MARIA | Angel
 PARIS      | GUSTAVO  | Luiz
 PARIS      | MBAPPE   | Kylian
 PARIS      | NEYMAR   | Da Silva Santos Jr
(10 lignes)

/*

Question 6 :
A partir de la vue précédente , recréez une vue 'joueurs_match_lens_paris_V' qui affichera les noms des joueurs ayant assisté à la rencontre Lens-Paris qui contiennent la lettre V (dans le nom).

*/

postgres=# create or replace view joueurs_match_lens_paris_V as select * from joueurs_match_lens_paris where nom like '%V%';
 nom_equipe |   nom   | prenom
------------+---------+---------
(4 lignes)

/*

Question 7 :
Donnez la requête qui permet de supprimer les 2 vues créées précédemment en une seule fois.

*/

postgres=# drop view joueurs_match_lens_paris cascade;
NOTICE:  DROP cascade sur vue joueurs_match_lens_paris_v
DROP VIEW

/*

   +--HURDEBOURCQ PAUL--+
   --TP6 BDD 16/05 | S2--
   +------TD1=>TPB------+