/* insertion de tuples dans la table composer_de


CREATE TABLE composer_de (id_saison integer references saison(id_saison), id_journee integer references journee(id_journee), primary key (id_saison, id_journee));

*/



insert into composer_de values (1, 1);
