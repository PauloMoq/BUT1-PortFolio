/* insertion de tuples dans la table stade

CREATE TABLE stade (id_stade integer primary key, nom_stade varchar(100), capacite_stade integer, ville_stade varchar(100));



*/



insert into equipe values (1, 'LENS');
insert into equipe values (2, 'PARIS');
insert into equipe values (3, 'MONACO');
insert into equipe values (4, 'MARSEILLE');
insert into equipe values (5, 'LYON');
insert into equipe values (6, 'NANTES');
insert into equipe values (7, 'MONTPELLIER');
insert into equipe values (8, 'BORDEAUX');
insert into equipe values (9, 'RENNES');
insert into equipe values (10, 'NICE');
insert into equipe values (11,  'GUINGAMP');
insert into equipe values (12,  'CAEN');
insert into equipe values (13, 'DIJON');
insert into equipe values (14, 'STRASBOURG');
insert into equipe values (15,  'SAINT-ETIENNE');
insert into equipe values (16, 'TOULOUSE');
insert into equipe values (17, 'LILLE');
insert into equipe values (18, 'AMIENS');
insert into equipe values (19, 'ANGERS');
insert into equipe values (20, 'TROYES');
insert into equipe values (21, 'METZ');
insert into equipe values (22, 'REIMS');
insert into equipe values (23, 'AJACCIO');
insert into equipe values (24, 'PARIS_FC');
insert into equipe values (25, 'NIMES');
insert into equipe values (26, 'LE_HAVRE');
insert into equipe values (27, 'CLERMONT-FERRAND');
insert into equipe values (28, 'LORIENT');
insert into equipe values (29, 'CHATEAUROUX');
insert into equipe values (30, 'SOCHAUX');
insert into equipe values (31,  'BREST');
insert into equipe values (32,  'ORLEANS');
insert into equipe values (33,  'AUXERRE');
insert into equipe values (34,  'VALENCIENNES');
insert into equipe values (35,  'GAZELEC AJACCIO');
insert into equipe values (36,  'NIORT');
insert into equipe values (40, 'NANCY');
insert into equipe values (37, 'ROUEN');
insert into equipe values (38, 'BOURG-EN-BRESSE');
insert into equipe values (39,  'TOURS');
