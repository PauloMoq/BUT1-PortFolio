/* insertion de tuples dans la table nationalite  */

insert into nationalite values (1,'FRA');
insert into nationalite values (2,'GER');
insert into nationalite values (3,'BEL');
insert into nationalite values (4,'ITA');
insert into nationalite values (5,'ESP');
insert into nationalite values (6,'GB');
insert into nationalite values (7,'PORTUGAL');
insert into nationalite values (8,'HOLL');insert into nationalite values (8,'HOLL');