/* insertion de tuples dans la table stade

CREATE TABLE stade (id_stade integer primary key, nom_stade varchar(100), capacite_stade integer, ville_stade varchar(100));



*/



insert into stade values (1, 'Stade Bolleart Delelis', 42000, 'LENS');
insert into stade values (2, 'Parc des Princes', 48000, 'PARIS');
insert into stade values (3, 'Stade Louis II', 18500, 'MONACO');
insert into stade values (4, 'Vélodrome', 67000, 'MARSEILLE');
insert into stade values (5, 'Parc OL', 58000, 'DECINES-CHARPIEU');
insert into stade values (6, 'La Beaujoire', 37000, 'NANTES');
insert into stade values (7, 'La Mosson', 32000, 'MONTPELLIER');
insert into stade values (8, 'Matmut Atlantique', 42000, 'BORDEAUX');
insert into stade values (9, 'Roazhon Park', 29000, 'RENNES');
insert into stade values (10, 'Allianz Riviera', 35000, 'NICE');
insert into stade values (11, 'Roudourou', 18200, 'GUINGAMP');
insert into stade values (12, 'Michel-d"Ornano', 21250, 'CAEN');
insert into stade values (13, 'Gaston-Gérard', 22000, 'DIJON');
insert into stade values (14, 'La Meinau', 27500, 'STRASBOURG');
insert into stade values (15, 'Geoffroy-Guichard', 41100, 'SAINT-ETIENNE');
insert into stade values (16, 'Stadium Municipal', 33300, 'TOULOUSE');
insert into stade values (17, 'Pierre-Mauroy', 50000, 'VILLENEUVE D"ASCQ');
insert into stade values (18, 'La Licorne', 12000, 'AMIENS');
insert into stade values (19, 'Raymond Kopa', 17800, 'ANGERS');
insert into stade values (20, 'Stade de l"Aube', 20000, 'TROYES');
insert into stade values (21, 'Saint-Symphorien', 25000, 'LONGEVILLE-LES-METZ');
insert into stade values (22, 'Auguste-Delaune', 21000, 'REIMS');
insert into stade values (23, 'Francois-Coty', 10800, 'AJACCIO');
insert into stade values (24, 'Charléty', 20000, 'PARIS');
insert into stade values (25, 'Les Costières', 18400, 'NIMES');
insert into stade values (26, 'Stade Océane', 25000, 'HAVRE');
insert into stade values (27, 'Gabriel-Montpied', 25000, 'CLERMONT-FERRAND');
insert into stade values (28, 'Yves-Allaintmat', 16400, 'LORIENT');
insert into stade values (29, 'Gaston-Petit', 17000, 'CHATEAUROUX');
insert into stade values (30, 'Auguste-Bonal', 20000, 'MONTBELIARD');
insert into stade values (31, 'Francis-Le Blé', 15000, 'BREST');
insert into stade values (32, 'Stade de la Source', 6900, 'ORLEANS');
insert into stade values (33, 'Abbé-Deschamps', 21300, 'AUXERRE');
insert into stade values (34, 'Stade du Hainaut', 24900, 'VALENCIENNES');
insert into stade values (35, 'Ange-Casanova', 10000, 'MEZZAVIA');
insert into stade values (36, 'René-Gaillard', 11000, 'NIORT');
insert into stade values (36, 'Marcel-Picot', 20000, 'TOMBLAINE');
insert into stade values (37, 'Robert-Diochon', 12000, 'PETIT-QUEVILLY');
insert into stade values (38, 'Marcel-Verchère', 5500, 'BOURG-EN-BRESSE');
insert into stade values (39, 'Stade de la Vallée du Cher', 16200, 'TOURS');
