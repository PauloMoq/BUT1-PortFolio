/* insertion de tuples dans la table but


CREATE TABLE but (id_but integer primary key, minute integer, type varchar(100), id_personne integer references personne(id_personne), id_match integer references match(id_match), check (minute between 0 and 120));

*/



insert into but values (1, 55, 'tete',1, 1);
insert into but values (2, 45,'pied gauche', 2, 2);
insert into but values (3, 55, 'tete',2, 3);
insert into but values (4, 45,'pied gauche', 2, 3);
insert into but values (5, 14, 'tete',1, 1);
insert into but values (6, 10,'pied gauche', 2, 2);
insert into but values (7, 91, 'tete',2, 3);
insert into but values (8, 82,'pied droit', 2, 3);
insert into but values (9, 35, 'tete',1, 1);
insert into but values (10, 25,'pied gauche', 2, 2);
insert into but values (11, 26, 'tete',2, 3);
insert into but values (12, 47,'pied gauche', 2, 3);
insert into but values (13, 3, 'tete',1, 1);
insert into but values (14, 6,'pied gauche', 2, 2);
insert into but values (15, 91, 'tete',2, 3);
insert into but values (16, 82,'pied droit', 2, 3);

