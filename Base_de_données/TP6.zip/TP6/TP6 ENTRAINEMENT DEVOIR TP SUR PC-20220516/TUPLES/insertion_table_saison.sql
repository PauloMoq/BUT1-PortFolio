/* insertion de tuples dans la table saison


CREATE TABLE saison (id_saison integer primary key, libelle_saison varchar (100), date_debut date, date_fin date);

*/


SET datestyle = "ISO, DMY"; -- pour mettre en format date européen

insert into saison values (1,'2017-2018', '01/08/2017','30/06/2018');



insert into saison values (2,'2018-2019', '01/08/2018','30/06/2019');