/* insertion de tuples dans la table media

CREATE TABLE media (id_media integer primary key, libelle_media varchar (100));

*/



insert into media values (1, 'lequipe');
insert into media values (2, 'le10sport');
insert into media values (3, 'aujourdhui_sport');
insert into media values (4, 'les_cahiers_du_football');
insert into media values (5, 'direct_sport');
insert into media values (5, 'football_et_sports_athletiques');
insert into media values (6, 'football_magazine');
insert into media values (7, 'france_football');
insert into media values (8, 'onze_mondial');
insert into media values (9, 'so_foot');
insert into media values (10, 'le_sport');
insert into media values (11, 'sport_colonial');
insert into media values (12, 'sporting');
insert into media values (13, 'sports_auvergne');
insert into media values (14, '11_freunde');
insert into media values (15, 'futbolnyy zhurnal');
insert into media values (16, 'kicker');
insert into media values (17, 'sports_bild');
insert into media values (18, 'jewish_sports_review');
insert into media values (19, 'eventing');
insert into media values (20, 'the_field');
insert into media values (21, 'wee_red_book');
insert into media values (22, 'the_celtic_view');
insert into media values (23, 'match');
insert into media values (24, 'the_sporting_magazine');
insert into media values (25, 'sportspro');
insert into media values (26, 'total_football');
insert into media values (27, 'when_staurday_comes');
insert into media values (28, 'world_soccer');
insert into media values (29, '1900');
insert into media values (30, 'voetbal_international');
insert into media values (31, 'soccer_america');
insert into media values (32, 'usa_today_sports_weekly');
insert into media values (33, 'sports_journal');
insert into media values (34, 'play');
insert into media values (35, 'pro_footabll_weekly');
insert into media values (36, 'planet_muscle');
insert into media values (37, 'outside');
insert into media values (38, 'milo');
insert into media values (39, 'athletics_weekly');
insert into media values (40, 'five');


