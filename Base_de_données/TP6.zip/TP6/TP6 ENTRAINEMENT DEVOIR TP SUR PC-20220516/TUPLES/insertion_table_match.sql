/* insertion de tuples dans la table match


CREATE TABLE  match (id_match integer primary key, nbre_spectateurs integer, date_match date, id_arbitre integer references personne(id_personne), id_equipe_recoit integer references equipe(id_equipe), id_equipe_deplace integer references equipe(id_equipe), id_journee integer references journee(id_journee), id_stade integer references stade(id_stade), check (id_equipe_recoit <> id_equipe_deplace));


*/



insert into match values (1, 10000, '08/08/2017', 101, 1,2,1,1);

insert into match values (2, 10000, '08/08/2017', 101, 1,3,1,1);

insert into match values (3, 10000, '08/08/2017', 101, 1,3,1,1);

insert into match values (4, 10000, '08/08/2017', 101, 1,4,1,1);

insert into match values (5, 10000, '08/08/2017', 101, 2,3,1,2);

insert into match values (6, 10000, '08/08/2017', 101, 2,4,1,2);

insert into match values (7, 10000, '08/08/2017', 101, 2,5,1,2);

insert into match values (8, 10000, '08/08/2017', 101, 2,5,1,3);

insert into match values (9, 10000, '08/08/2017', 101, 3,6,1,4);

insert into match values (10, 10000, '08/08/2017', 101, 3,7,1,4);

insert into match values (11, 10000, '08/08/2017', 101, 3,8,1,4);

insert into match values (12, 10000, '08/08/2017', 101, 3,9,1,4);

insert into match values (13, 10000, '08/08/2017', 101, 4,10,1,5);

insert into match values (14, 10000, '08/08/2017', 101, 4,11,1,5);

insert into match values (15, 10000, '08/08/2017', 101, 4,12,1,5);

insert into match values (16, 10000, '08/08/2017', 101, 4,13,1,5);

insert into match values (17, 10000, '08/08/2017', 101, 5,14,1,6);

insert into match values (18, 10000, '08/08/2017', 101, 5,15,1,6);

insert into match values (19, 10000, '08/08/2017', 101, 5,15,1,7);

insert into match values (20, 10000, '08/08/2017', 101, 5,15,1,8);

insert into match values (21, 10000, '08/08/2017', 101, 6,16,1,8);

insert into match values (22, 10000, '08/08/2017', 101, 6,17,1,8);

insert into match values (23, 10000, '08/08/2017', 101, 6,18,1,9);

insert into match values (24, 10000, '08/08/2017', 101, 6,19,1,9);




insert into match values (25, 10000, '08/08/2017', 101, 7,20,1,10);

insert into match values (26, 10000, '08/08/2017', 101, 7,21,1,11);

insert into match values (27, 10000, '08/08/2017', 101, 7,22,1,10);

insert into match values (28, 10000, '08/08/2017', 101, 7,23,1,11);


insert into match values (29, 10000, '08/08/2017', 101, 8,24,1,12);

insert into match values (30, 10000, '08/08/2017', 101, 8,25,1,12);

insert into match values (31, 10000, '08/08/2017', 101, 8,26,1,13);

insert into match values (32, 10000, '08/08/2017', 101, 8,27,1,14);


insert into match values (33, 10000, '08/08/2017', 101, 9,28,1,13);

insert into match values (34, 10000, '08/08/2017', 101, 9,29,1,14);

insert into match values (35, 10000, '08/08/2017', 101, 9,30,1,15);

insert into match values (36, 10000, '08/08/2017', 101, 9,31,1,16);



insert into match values (37, 10000, '08/08/2017', 101, 10,32,1,17);

insert into match values (38, 10000, '08/08/2017', 101, 1,33,1,18);

insert into match values (39, 10000, '08/08/2017', 101, 10,34,1,17);

insert into match values (40, 10000, '08/08/2017', 101, 10,34,1,18);