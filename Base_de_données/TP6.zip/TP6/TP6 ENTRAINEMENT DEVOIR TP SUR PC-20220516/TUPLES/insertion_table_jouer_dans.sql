/* insertion de tuples dans la table jouer_dans

CREATE TABLE jouer_dans (id_personne integer references personne(id_personne), id_equipe integer references equipe(id_equipe), date_debut_contrat date,
                        date_fin_contrat date, poste varchar (100), numero integer , primary key (id_personne, id_equipe));
                        
Vous mettez simplement les mêmes dates de début et de fin puis null et encore null

*/

insert into jouer_dans values (1, 1, '01/09/2015','01/07/2020', null, null);

insert into jouer_dans values (2, 1, '01/09/2015','01/07/2020', null, null);


insert into jouer_dans values (3, 1, '01/09/2015','01/07/2020', null, null);

insert into jouer_dans values (4, 1, '01/09/2015','01/07/2020', null, null);

insert into jouer_dans values (5, 1, '01/09/2015','01/07/2020', null, null);

insert into jouer_dans values (6, 2, '01/09/2015','01/07/2020', null, null);

insert into jouer_dans values (7, 2, '01/09/2015','01/07/2020', null, null);


insert into jouer_dans values (8,2, '01/09/2015','01/07/2020', null, null);

insert into jouer_dans values (9,2, '01/09/2015','01/07/2020', null, null);

insert into jouer_dans values (10, 2, '01/09/2015','01/07/2020', null, null);

insert into jouer_dans values (11, 3, '01/09/2015','01/07/2020', null, null);

insert into jouer_dans values (12, 3, '01/09/2015','01/07/2020', null, null);

insert into jouer_dans values (13, 43 '01/09/2015','01/07/2020', null, null);

insert into jouer_dans values (14, 3, '01/09/2015','01/07/2020', null, null);

insert into jouer_dans values (15, 3, '01/09/2015','01/07/2020', null, null);

insert into jouer_dans values (16, 4, '01/09/2015','01/07/2020', null, null);

insert into jouer_dans values (17, 4, '01/09/2015','01/07/2020', null, null);


insert into jouer_dans values (18, 4, '01/09/2015','01/07/2020', null, null);

insert into jouer_dans values (19, 4, '01/09/2015','01/07/2020', null, null);

insert into jouer_dans values (20, 4, '01/09/2015','01/07/2020', null, null);

insert into jouer_dans values (21, 5, '01/09/2015','01/07/2020', null, null);

insert into jouer_dans values (22, 5, '01/09/2015','01/07/2020', null, null);


insert into jouer_dans values (23, 5, '01/09/2015','01/07/2020', null, null);

insert into jouer_dans values (24, 5, '01/09/2015','01/07/2020', null, null);

insert into jouer_dans values (25, 5, '01/09/2015','01/07/2020', null, null);


insert into jouer_dans values (26, 6, '01/09/2015','01/07/2020', null, null);

insert into jouer_dans values (27, 7, '01/09/2015','01/07/2020', null, null);


insert into jouer_dans values (28, 7, '01/09/2015','01/07/2020', null, null);

insert into jouer_dans values (29, 7, '01/09/2015','01/07/2020', null, null);

insert into jouer_dans values (30, 7, '01/09/2015','01/07/2020', null, null);


insert into jouer_dans values (31, 8, '01/09/2015','01/07/2020', null, null);

insert into jouer_dans values (32, 8, '01/09/2015','01/07/2020', null, null);


insert into jouer_dans values (33, 8, '01/09/2015','01/07/2020', null, null);

insert into jouer_dans values (34, 8, '01/09/2015','01/07/2020', null, null);

insert into jouer_dans values (35, 8, '01/09/2015','01/07/2020', null, null);

insert into jouer_dans values (36, 9, '01/09/2015','01/07/2020', null, null);

insert into jouer_dans values (37, 9, '01/09/2015','01/07/2020', null, null);


insert into jouer_dans values (38, 9, '01/09/2015','01/07/2020', null, null);

insert into jouer_dans values (39, 9, '01/09/2015','01/07/2020', null, null);

insert into jouer_dans values (40,9, '01/09/2015','01/07/2020', null, null,);

insert into jouer_dans values (41, 10, '01/09/2015','01/07/2020', null, null);

insert into jouer_dans values (42, 10, '01/09/2015','01/07/2020', null, null);


insert into jouer_dans values (43, 10, '01/09/2015','01/07/2020', null, null);

insert into jouer_dans values (44, 10, '01/09/2015','01/07/2020', null, null);

insert into jouer_dans values (45, 10, '01/09/2015','01/07/2020', null, null);

insert into jouer_dans values (46, 11, '01/09/2015','01/07/2020', null, null);

insert into jouer_dans values (47, 11, '01/09/2015','01/07/2020', null, null);


insert into jouer_dans values (48, 11, '01/09/2015','01/07/2020', null, null);

insert into jouer_dans values (49, 11, '01/09/2015','01/07/2020', null, null);

insert into jouer_dans values (50, 11, '01/09/2015','01/07/2020', null, null);

insert into jouer_dans values (51, 12, '01/09/2015','01/07/2020', null, null);

insert into jouer_dans values (52, 12, '01/09/2015','01/07/2020', null, null);


insert into jouer_dans values (53, 12, '01/09/2015','01/07/2020', null, null);

insert into jouer_dans values (54, 12, '01/09/2015','01/07/2020', null, null);

insert into jouer_dans values (55, 12, '01/09/2015','01/07/2020', null, null);

insert into jouer_dans values (56, 13, '01/09/2015','01/07/2020', null, null);

insert into jouer_dans values (57, 13, '01/09/2015','01/07/2020', null, null);


insert into jouer_dans values (58, 13, '01/09/2015','01/07/2020', null, null);

insert into jouer_dans values (59, 13, '01/09/2015','01/07/2020', null, null);

insert into jouer_dans values (60, 13, '01/09/2015','01/07/2020', null, null);


insert into jouer_dans values (61, 14, '01/09/2015','01/07/2020', null, null);

insert into jouer_dans values (62, 14, '01/09/2015','01/07/2020', null, null);


insert into jouer_dans values (63, 14, '01/09/2015','01/07/2020', null, null);

insert into jouer_dans values (64, 14, '01/09/2015','01/07/2020', null, null);

insert into jouer_dans values (65, 14, '01/09/2015','01/07/2020', null, null);

insert into jouer_dans values (66, 15, '01/09/2015','01/07/2020', null, null);

insert into jouer_dans values (67, 15, '01/09/2015','01/07/2020', null, null);


insert into jouer_dans values (68, 15, '01/09/2015','01/07/2020', null, null);

insert into jouer_dans values (69, 15, '01/09/2015','01/07/2020', null, null);

insert into jouer_dans values (70, 15, '01/09/2015','01/07/2020', null, null);


insert into jouer_dans values (71, 16, '01/09/2015','01/07/2020', null, null);

insert into jouer_dans values (72, 16, '01/09/2015','01/07/2020', null, null);


insert into jouer_dans values (73, 16, '01/09/2015','01/07/2020', null, null);

insert into jouer_dans values (74, 16, '01/09/2015','01/07/2020', null, null);

insert into jouer_dans values (75, 16, '01/09/2015','01/07/2020', null, null);

insert into jouer_dans values (76, 17, '01/09/2015','01/07/2020', null, null);

insert into jouer_dans values (77, 17, '01/09/2015','01/07/2020', null, null);


insert into jouer_dans values (78, 17, '01/09/2015','01/07/2020', null, null);

insert into jouer_dans values (79, 17, '01/09/2015','01/07/2020', null, null);

insert into jouer_dans values (80, 17, '01/09/2015','01/07/2020', null, null);

insert into jouer_dans values (81, 18, '01/09/2015','01/07/2020', null, null);

insert into jouer_dans values (82, 18, '01/09/2015','01/07/2020', null, null);


insert into jouer_dans values (83, 18, '01/09/2015','01/07/2020', null, null);

insert into jouer_dans values (84, 18, '01/09/2015','01/07/2020', null, null);

insert into jouer_dans values (85, 18, '01/09/2015','01/07/2020', null, null);


insert into jouer_dans values (86, 19, '01/09/2015','01/07/2020', null, null);

insert into jouer_dans values (87, 19, '01/09/2015','01/07/2020', null, null);


insert into jouer_dans values (88, 19, '01/09/2015','01/07/2020', null, null);

insert into jouer_dans values (89, 19, '01/09/2015','01/07/2020', null, null);

insert into jouer_dans values (90, 19, '01/09/2015','01/07/2020', null, null);


insert into jouer_dans values (91, 20, '01/09/2015','01/07/2020', null, null);

insert into jouer_dans values (92, 20, '01/09/2015','01/07/2020', null, null);


insert into jouer_dans values (93,20, '01/09/2015','01/07/2020', null, null);

insert into jouer_dans values (94, 20, '01/09/2015','01/07/2020', null, null);

insert into jouer_dans values (95, 20, '01/09/2015','01/07/2020', null, null);

insert into jouer_dans values (96, 21, '01/09/2015','01/07/2020', null, null);

insert into jouer_dans values (97, 21, '01/09/2015','01/07/2020', null, null);


insert into jouer_dans values (98, 22, '01/09/2015','01/07/2020', null, null);

insert into jouer_dans values (99, 23, '01/09/2015','01/07/2020', null, null);

insert into jouer_dans values (100, 24, '01/09/2015','01/07/2020', null, null);