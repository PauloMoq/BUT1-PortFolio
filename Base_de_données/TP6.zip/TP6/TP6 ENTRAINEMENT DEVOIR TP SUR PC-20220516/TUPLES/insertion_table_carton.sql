/* insertion de tuples dans la table carton

CREATE TABLE carton (id_carton integer primary key, couleur_carton varchar(50));
                        

*/



insert into carton values (1, 'jaune');
insert into carton values (2, 'rouge');
insert into carton values (3, 'vert');

