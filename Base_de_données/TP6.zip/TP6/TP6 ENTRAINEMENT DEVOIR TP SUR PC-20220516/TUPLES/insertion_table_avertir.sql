/* insertion de tuples dans la table avertir

CREATE TABLE avertir (id_personne integer references personne(id_personne), id_carton integer references carton(id_carton), id_match integer references match(id_match), minutes integer, primary key (id_personne, id_carton, id_match), check (minute between 0 and 120));
                        


*/



insert into avertir values (1, 1, 1, 90);
insert into avertir values (1, 1, 2, 90);
insert into avertir values (1, 1, 3, 90);
insert into avertir values (1, 1, 4, 90);
insert into avertir values (1, 1, 5, 90);
insert into avertir values (1, 1, 6, 90);


