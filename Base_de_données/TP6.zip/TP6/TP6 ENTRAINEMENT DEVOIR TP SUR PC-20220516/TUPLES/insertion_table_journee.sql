/* insertion de tuples dans la table journee

CREATE TABLE journee (id_journee integer primary key, date_journee date);


*/



insert into journee values (1,'01/08/2017');
insert into journee values (2,'08/08/2017');
insert into journee values (3,'15/08/2017');
insert into journee values (4,'22/08/2017');
insert into journee values (5,'29/08/2017');
insert into journee values (6,'01/09/2017');
insert into journee values (7,'08/09/2017');
insert into journee values (8,'15/09/2017');
insert into journee values (9,'22/09/2017');
insert into journee values (10,'29/09/2017');
insert into journee values (11,'01/10/2017');
insert into journee values (12,'08/10/2017');
