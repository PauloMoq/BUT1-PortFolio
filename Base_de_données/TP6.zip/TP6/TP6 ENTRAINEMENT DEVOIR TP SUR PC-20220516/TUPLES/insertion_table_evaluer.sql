/* insertion de tuples dans la table evaluer

CREATE TABLE evaluer (id_personne integer references personne(id_personne), id_media integer references media(id_media), id_match integer references match(id_match), note integer, check (note between 0 and 10), primary key (id_personne,id_media,id_match));

*/



insert into evaluer values (1, 1, 1, 10);
insert into evaluer values (1, 2, 1, 10);
insert into evaluer values (1, 3, 1, 10);
insert into evaluer values (1, 4, 1, 10);
insert into evaluer values (2, 1, 1, 8);
insert into evaluer values (2, 2, 1, 10);
insert into evaluer values (2, 3, 1, 6);
insert into evaluer values (2, 4, 1, 5);
insert into evaluer values (3, 1, 1, 0);
insert into evaluer values (3, 2, 1, 4);
insert into evaluer values (3, 3, 1, 3);
insert into evaluer values (3, 4, 1, 2);
insert into evaluer values (4, 1, 1, 8);
insert into evaluer values (4, 2, 1, 10);
insert into evaluer values (4, 3, 1, 6);
insert into evaluer values (4, 4, 1, 5);
