/* insertion de tuples dans la table participer

CREATE TABLE participer (id_equipe integer references equipe(id_equipe), id_saison integer references saison(id_saison), championnat varchar (100), primary key (id_equipe,id_saison));

*/



insert into participer values (1, 1, 'ligue1');
insert into participer values (2, 1, 'ligue1');
insert into participer values (3, 1, 'ligue1');
insert into participer values (4, 1, 'ligue1');
insert into participer values (5, 1, 'ligue1');
insert into participer values (6, 1, 'ligue1');
insert into participer values (7, 1, 'ligue1');
insert into participer values (8, 1, 'ligue1');

insert into participer values (9, 1, 'ligue1');
insert into participer values (10, 1, 'ligue1');
insert into participer values (11, 1, 'ligue1');
insert into participer values (12, 1, 'ligue1');
insert into participer values (13, 1, 'ligue1');
insert into participer values (14, 1, 'ligue1');
insert into participer values (15, 1, 'ligue1');
insert into participer values (16, 1, 'ligue1');

insert into participer values (17, 1, 'ligue1');
insert into participer values (18, 1, 'ligue1');
insert into participer values (19, 1, 'ligue1');
insert into participer values (20, 1, 'ligue1');
insert into participer values (21, 1, 'ligue1');
insert into participer values (22, 1, 'ligue1');
insert into participer values (23, 1, 'ligue1');
insert into participer values (24, 1, 'ligue1');

insert into participer values (25, 1, 'ligue1');
insert into participer values (26, 1, 'ligue1');
insert into participer values (27, 1, 'ligue1');
insert into participer values (28, 1, 'ligue1');
insert into participer values (29, 1, 'ligue1');
insert into participer values (30, 1, 'ligue1');
insert into participer values (31, 1, 'ligue1');
insert into participer values (32, 1, 'ligue1');