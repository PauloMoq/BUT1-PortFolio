/* création des tables de la bdd foot_votrenom */

CREATE TABLE equipe (id_equipe integer primary Key not null, nom_equipe varchar(100));

CREATE TABLE nationalite (id_nationalite integer primary key, libelle_nationalite varchar(100));

CREATE TABLE personne (id_personne integer primary key, nom varchar(100), prenom varchar(100), date_naissance date, id_nationalite integer references nationalite(id_nationalite));

CREATE TABLE media (id_media integer primary key, libelle_media varchar (100));

CREATE TABLE saison (id_saison integer primary key, libelle_saison varchar (100), date_debut date, date_fin date);

CREATE TABLE journee (id_journee integer primary key, date_journee date);

CREATE TABLE carton (id_carton integer primary key, couleur_carton varchar(50));

CREATE TABLE stade (id_stade integer primary key, nom_stade varchar(100), capacite_stade integer, ville_stade varchar(100));


CREATE TABLE jouer_dans (id_personne integer references personne(id_personne), id_equipe integer references equipe(id_equipe), date_debut_contrat date,
                        date_fin_contrat date, poste varchar (100), numero integer , primary key (id_personne, id_equipe));
                        

CREATE TABLE participer (id_equipe integer references equipe(id_equipe), id_saison integer references saison(id_saison), championnat varchar (100), primary key (id_equipe,id_saison));
    

CREATE TABLE composer_de (id_saison integer references saison(id_saison), id_journee integer references journee(id_journee), primary key (id_saison, id_journee));


CREATE TABLE  match (id_match integer primary key, nbre_spectateurs integer, date_match date, id_arbitre integer references personne(id_personne), id_equipe_recoit integer references equipe(id_equipe), id_equipe_deplace integer references equipe(id_equipe), id_journee integer references journee(id_journee), id_stade integer references stade(id_stade), check (id_equipe_recoit <> id_equipe_deplace));


CREATE TABLE evaluer (id_personne integer references personne(id_personne), id_media integer references media(id_media), id_match integer references match(id_match), note integer, primary key (id_personne,id_media,id_match), check (note between 0 and 10));



CREATE TABLE but (id_but integer primary key, minute integer, type varchar(100), id_personne integer references personne(id_personne), id_match integer references match(id_match), check (minute between 0 and 120));


CREATE TABLE avertir (id_personne integer references personne(id_personne), id_carton integer references carton(id_carton), id_match integer references match(id_match), minutes integer, primary key (id_personne, id_carton, id_match));
                        



